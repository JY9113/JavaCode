package edu.java.exception08;

import java.util.Scanner;

public class ExMain08 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("메뉴 선택 >  ");
		int choice = sc.nextInt();
		System.out.println("choice : " + choice);

	}

}
